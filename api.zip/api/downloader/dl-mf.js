const puppeteer = require('puppeteer');
const cheerio = require("cheerio");

module.exports = function(app) {

  app.get('/download/mediafire', async (req, res) => { 
    const url = req.query.url;
    if (!url) {
      return res.status(400).json({
        error: 'Parameter "url" tidak ditemukan'
      });
    }

    try {
      const response = await kianaMediaFire(url);
      console.log(response)
      res.status(200).json({
        status: 200,
        creator: "fdteam",
        data: response 
      });
    } catch (error) {
      res.status(500).json({
        error: error.message
      });
    }
  });
};

async function kianaMediaFire(url) {
  const parseFileSize = async (filesizeH) => {
    const size = filesizeH.match(/([\d.]+)(\w+)/);
    if (!size) return 0;
    const value = parseFloat(size[1]);
    const unit = size[2].toUpperCase();

    const unitMultiplier = {
      B: 1,
      KB: 1024,
      MB: 1024 * 1024,
      GB: 1024 * 1024 * 1024
    };
    return value * (unitMultiplier[unit] || 1);
  }

  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
    headless: true 
  });

  const page = await browser.newPage();
  const userAgent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36';
  await page.setUserAgent(userAgent);

  try {
    await page.goto(url, { waitUntil: 'networkidle2' });
    const kianaImut = await page.content(); 
    console.log(kianaImut)
    const $ = cheerio.load(kianaImut);

    const Url = ($('#downloadButton').attr('href') || '').trim();
    const $intro = $('div.dl-info > div.intro');
    const filename = $intro.find('div.filename').text().trim();
    const filetype = $intro.find('div.filetype > span').eq(0).text().trim();
    const extMatch = $intro.find('div.filetype > span').eq(1).text().match(/\(\.(.*?)\)/);
    const ext = extMatch ? extMatch[1] : 'bin';
    const $li = $('div.dl-info > ul.details > li');
    const date_upload = $li.eq(1).find('span').text().trim();
    const filesizeH = $li.eq(0).find('span').text().trim();
    const filesize = await parseFileSize(filesizeH);

    const result = {
      url: Url,
      filename,
      filetype,
      ext,
      date_upload,
      filesize
    };

    await browser.close();
    return result;
  } catch (error) {
    await browser.close();
    console.error('Error fetching data:', error);
    throw error;
  }
}
