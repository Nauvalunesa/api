const axios = require('axios');

module.exports = function(app) {

app.get('/download/aiodl', async (req, res) => {
    try {
      const url = req.query.url;
      if (!url) {
        return res.status(400).json({ error: 'Parameter "url" tidak ditemukan' });
      }
      const response = await axios.get("https://ytapi.hoshiliz.my.id/dl-aiodl?text=" + url, {
        headers: {
          Authorization: 'Bearer veliona'
        }
      });
      const data = response.data.urls;
      res.status(200).json({
        status: 200,
        creator: "fdteam",
        data
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
};