/*
wa.me/6289687537657
github: https://github.com/Phmiuuu
Instagram: https://instagram.com/basrenggood
ini wm gw cok jan di hapus
*/

const axios = require('axios');
const cheerio = require("cheerio")
module.exports = function(app) {

app.get('/downloader/tiktok', async (req, res) => {
    try {
      const url = req.query.url;
      if (!url) {
        return res.status(400).json({ error: 'Parameter "url" tidak ditemukan' });
      }
       const Tiktok = async (urls) => {
    const url = "https://tiktokio.com/api/v1/tk-htmx";
    const data = new URLSearchParams({
        prefix: "dtGslxrcdcG9raW8uY29t",
        vid: urls,
    });

    const config = {
        headers: {
            "HX-Request": "true",
            "HX-Trigger": "search-btn",
            "HX-Target": "tiktok-parse-result",
            "HX-Current-URL": "https://tiktokio.com/id/",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data: data,
    };

    try {
        let {
            data: res
        } = await axios.post(url, data, config);
        let $ = cheerio.load(res);
        const urls = [];
        let media;

        const links = {
            status: 200,
            creator: "FD-Team",
            isSlide: false,
            title: $("h2").text(),
            media: media,
        };

        $(".download-item img").each((index, element) => {
            const url = $(element).attr("src");
            urls.push(url);
            links.isSlide = true;
        });

        if (urls.length === 0) {
            media = {};
            $("div.tk-down-link").each(function(index, element) {
                const linkType = $(this).find("a").text().trim();
                const url = $(this).find("a").attr("href");

                if (linkType === "Download watermark") {
                    media["watermark"] = url;
                } else if (linkType === "Download Mp3") {
                    media["mp3"] = url;
                } else if (linkType === "Download without watermark") {
                    media["no_wm"] = url;
                } else if (linkType === "Download without watermark (HD)") {
                    media["hd"] = url;
                }
            });
        } else {
            media = urls;
        }
        links.media = media;

        return links;
    } catch (e) {
        return {
            status: 404,
            msg: e,
        };
    }
}
    let hasil = await Tiktok(url)
    res.status(200).json({
        hasil
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
};