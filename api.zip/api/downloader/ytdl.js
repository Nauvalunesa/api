/*
wa.me/6289687537657
github: https://github.com/Phmiuuu
Instagram: https://instagram.com/basrenggood
ini wm gw cok jan di hapus
*/

const axios = require("axios");
const yts = require('yt-search');
const express = require('express');
const app = express();

module.exports = function(app) {
  app.use(express.json());
  app.post('/downloader/ytdl', async (req, res) => {
    try {
      const { url, mp4, mp3 } = req.body;

      if (!url) {
        return res.status(400).json({ error: 'Parameter "url" tidak ditemukan' });
      }

      const extractVid = (data) => {
        const match = /(?:youtu\.be\/|youtube\.com(?:.*[?&]v=|.*\/))([^?&]+)/.exec(data);
        return match ? match[1] : null;
      };

      const info = async (link) => {
        let id = extractVid(link)
        const {
          title,
          description,
          url,
          videoId,
          seconds,
          timestamp,
          views,
          genre,
          uploadDate,
          ago,
          image,
          thumbnail,
          author
        } = await yts({
          videoId: id
        });
        return {
          title,
          description,
          url,
          videoId,
          seconds,
          timestamp,
          views,
          genre,
          uploadDate,
          ago,
          image,
          thumbnail,
          author
        };
      };

      const downloadVideo = async (url, downtype, vquality) => {
        const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:shorts\/|watch\?v=|music\?v=|embed\/|v\/|.+\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
        const match = url.match(regex);
        const videoId = match[1];
        const data = new URLSearchParams({
          videoid: videoId,
          downtype,
          vquality
        });

        const response = await axios.post('https://api-cdn.saveservall.xyz/ajax-v2.php', data, {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
        });
        return response.data.url;
      }

      const download = async (urlnya, {
        mp4 = '360',
        mp3 = '128'
      } = {}) => {
        const mp4Link = await downloadVideo(urlnya, 'mp4', mp4);
        const mp3Link = await downloadVideo(urlnya, 'mp3', mp3);
        const data = await info(urlnya) || null
        res.status(200).json({
          status: 200,
          creator: "FD-Team",
          result: {
            metadata: {
              title: data.title,
              description: data.description,
              url: data.url,
              videoId: data.videoId,
              seconds: data.seconds,
              timestamp: data.timestamp,
              views: data.views,
              genre: data.genre,
              uploadDate: data.uploadDate,
              ago: data.ago,
              image: data.image,
              thumbnail: data.thumbnail,
              author: {
                name: data.author.name,
                url: data.author.url
              }
            },
            mp4: mp4Link,
            mp3: mp3Link
          }
        });
      }

      return download(url, { mp4, mp3 })
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
};