/*
wa.me/6289687537657
github: https://github.com/Phmiuuu
Instagram: https://instagram.com/basrenggood
ini wm gw cok jan di hapus
*/

const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function(app) {
    async function fetchJournals(query) {
        const url = `https://sinta.kemdikbud.go.id/authors?q=${encodeURIComponent(query)}`;
        try {
            const { data } = await axios.get(url, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36',
                },
            });

            const $ = cheerio.load(data);
            const journals = [];

            $('.au-list-det').each((index, element) => {
                const title = $(element).find('h5 a').text().trim();
                const link = $(element).find('h5 a').attr('href');
                const affiliation = $(element).find('.affil').text().trim();

                if (title && link) {
                    journals.push({
                        title,
                        link: `https://sinta.kemdikbud.go.id${link}`,
                        affiliation: affiliation || 'Tidak ada afiliasi',
                    });
                }
            });

            return journals;
        } catch (error) {
            console.error('Error fetching data:', error.message);
            return [];
        }
    }

    app.get('/carijurnal', async (req, res) => {
        const { search } = req.query;
        if (!search) {
            return res.status(400).json({ error: 'Parameter "search" diperlukan' });
        }

        try {
            const results = await fetchJournals(search);
            if (results.length === 0) {
                res.status(200).json({ message: 'Tidak ditemukan hasil' });
            } else {
                res.status(200).json(results);
            }
        } catch (error) {
            res.status(500).json({ error: 'Gagal mengambil data jurnal' });
        }
    });
};