const { fetch: fetchUndici } = require("undici");
const FormData = require("form-data");
const fakeUserAgent = require("fake-useragent");

const BING_URL = "https://www.bing.com";
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const generateRandomIP = () => {
  const randomOctet = () => Math.floor(Math.random() * 256);
  return `${randomOctet()}.${randomOctet()}.${randomOctet()}.${randomOctet()}`;
};

const generateRandomUserAgent = () => {
  const versions = ["4.0.3", "4.1.1", "4.2.2", "4.3", "4.4", "5.0.2", "5.1", "6.0", "7.0", "8.0", "9.0", "10.0", "11.0"];
  const devices = ["M2004J19C", "S2020X3", "Xiaomi4S", "RedmiNote9", "SamsungS21", "GooglePixel5"];
  const buildNumbers = ["RP1A.200720.011", "RP1A.210505.003", "RP1A.210812.016", "QKQ1.200114.002", "RQ2A.210505.003"];
  
  const device = devices[Math.floor(Math.random() * devices.length)];
  const build = buildNumbers[Math.floor(Math.random() * buildNumbers.length)];
  const chromeVersion = `Chrome/${Math.floor(Math.random() * 80) + 1}.${Math.floor(Math.random() * 999) + 1}.${Math.floor(Math.random() * 9999) + 1}`;
  
  return `Mozilla/5.0 (Linux; Android ${versions[Math.floor(Math.random() * versions.length)]}; ${device} Build/${build}) AppleWebKit/537.36 (KHTML, like Gecko) ${chromeVersion} Mobile Safari/537.36 WhatsApp/1.${Math.floor(Math.random() * 9) + 1}.${Math.floor(Math.random() * 9) + 1}`;
};

const getValidIPv4 = (ip) => {
  const isValid = !ip || ip.match(/^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\/([0-9]|[1-2][0-9]|3[0-2]))?$/);
  if (isValid) {
    if (isValid[5]) {
      const mask = parseInt(isValid[5], 10);
      let [octet1, octet2, octet3, octet4] = ip.split(".").map(Number);
      const randomNum = (1 << 32 - mask) - 1;
      const randomOffset = Math.floor(Math.random() * randomNum);
      octet4 += randomOffset;
      octet3 += Math.floor(octet4 / 256);
      octet4 %= 256;
      octet2 += Math.floor(octet3 / 256);
      octet3 %= 256;
      octet1 += Math.floor(octet2 / 256);
      octet2 %= 256;
      return `${octet1}.${octet2}.${octet3}.${octet4}`;
    }
    return ip;
  }
  return undefined;
};

class BingImageCreator {
  static HEADERS = {
    accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "en-US,en;q=0.9",
    "cache-control": "max-age=0",
    "content-type": "application/x-www-form-urlencoded",
    referrer: "https://www.bing.com/images/create/",
    origin: "https://www.bing.com",
    "user-agent": fakeUserAgent() || generateRandomUserAgent(),
    "x-forwarded-for": getValidIPv4(generateRandomIP()) || generateRandomIP()
  };

  constructor({ cookie }) {
    this._cookie = "_U=" + cookie;
    if (!this._cookie) {
      throw new Error("Bing cookie is required");
    }
  }

  async fetchRedirectUrl(url, body) {
    const response = await fetchUndici(url, {
      method: "POST",
      mode: "cors",
      credentials: "include",
      headers: {
        cookie: this._cookie,
        ...BingImageCreator.HEADERS
      },
      body,
      redirect: "manual"
    });
    
    if (response.ok) {
      throw new Error("Request failed");
    } else {
      const location = response.headers.get("location").replace("&nfy=1", "");
      const requestId = location.split("id=")[1];
      return { redirect_url: location, request_id: requestId };
    }
  }

  async fetchResult(query, redirectUrl, requestId) {
    console.log("redirect_url is ", redirectUrl);
    console.log("request_id is ", requestId);
    
    try {
      await fetchUndici(`${BING_URL}${redirectUrl}`, {
        method: "GET",
        mode: "cors",
        credentials: "include",
        headers: {
          cookie: this._cookie,
          ...BingImageCreator.HEADERS
        }
      });
    } catch (error) {
      throw new Error(`Request redirect_url failed: ${error.message}`);
    }

    const resultUrl = `${BING_URL}/images/create/async/results/${requestId}?q=${query}`;
    const startTime = Date.now();
    let result;

    while (true) {
      console.log("Waiting for result...");
      if (Date.now() - startTime > 200000) {
        throw new Error("Timeout");
      }
      await sleep(1000);
      result = await this.getResults(resultUrl);
      if (result) break;
    }

    return this.parseResult(result);
  }

  async getResults(url) {
    const response = await fetchUndici(url, {
      method: "GET",
      mode: "cors",
      credentials: "include",
      headers: {
        cookie: this._cookie,
        ...BingImageCreator.HEADERS
      }
    });
    
    if (response.status !== 200) {
      throw new Error("Bad status code");
    }

    const text = await response.text();
    if (!text || text.includes("errorMessage")) {
      return null;
    } else {
      return text;
    }
  }

  parseResult(html) {
    console.log("Parsing result...");
    const regex = /src="([^"]*)"/g;
    const matches = [...html.matchAll(regex)].map(match => match[1]);
    const uniqueImages = [...new Set(matches.map(url => url.split("?w=")[0]))];
    const validImages = uniqueImages.filter(url => !/r.bing.com\/rp/i.test(url));
    
    if (validImages.length !== uniqueImages.length) {
      console.log("Detected & Removed bad images");
    }
    
    if (validImages.length === 0) {
      throw new Error("error_no_images");
    }
    
    return validImages;
  }

  async fetchRedirectUrlWithRetry(url, body, maxRetries = 30) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await this.fetchRedirectUrl(url, body);
      } catch (error) {
        console.log(`Retry ${attempt + 1} time`);
        if (attempt === maxRetries - 1) {
          throw new Error(`Max retries reached: ${error.message}`);
        }
      }
    }
  }

  async fetchResultWithRetry(query, redirectUrl, requestId, maxRetries = 30) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await this.fetchResult(query, redirectUrl, requestId);
      } catch (error) {
        console.log(`Retry ${attempt + 1} time`);
        if (attempt === maxRetries - 1) {
          throw new Error(`Max retries reached: ${error.message}`);
        }
      }
    }
  }

  async getResultsWithRetry(url, maxRetries = 30) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await this.getResults(url);
      } catch (error) {
        console.log(`Retry ${attempt + 1} time`);
        if (attempt === maxRetries - 1) {
          throw new Error(`Max retries reached: ${error.message}`);
        }
      }
    }
  }
}

module.exports = BingImageCreator;
