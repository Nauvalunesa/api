const BingImageCreator = require('../scraper/bingGen.js')

module.exports = function(app) {

  app.get('/ai/bing-img', async (req, res) => { 
    const text = req.query.text;
    if (!text) {
      return res.status(400).json({
        error: 'Parameter "text" tidak ditemukan'
      });
    }

    try {
     const res = new BingImageCreator({
      cookie: `1Cge2z46hl1Y2d5jf_clMUcV11B4dZnDCs8MmHcRnbHPy5POqhghNOHDZdK-y1ZDZkpdBy5d3XQfbW853Pzr-USZu2VB1w4GfvC2yBqJO5nPoW4Cz-tRvoyMdFkylQ5_NRvOrD8QN4eTDrVV8tmjFz8FlYZHSM42yyxfPOrhr4sVYiDQcd8CUBKFubdHs01-a6eVh4WaH5fQOrba7KziqA`,
    });
    const data = await res.getResultsWithRetry(text) 
      console.log(response)
      res.status(200).json({
        status: 200,
        creator: "fdteam",
        data 
      });
    } catch (error) {
      res.status(500).json({
        error: error.message
      });
    }
  });
};      