/*
wa.me/6289687537657
github: https://github.com/Phmiuuu
Instagram: https://instagram.com/basrenggood
ini wm gw cok jan di hapus
*/

const axios = require("axios");

module.exports = function(app) {
  app.get('/ai/ragbot', async (req, res) => {
    try {
      const { q, logic } = req.query;
      if (!q) {
        return res.status(400).json({ error: 'Parameter "q" tidak ditemukan' });
      }
      if (!logic) {
        return res.status(400).json({ error: 'Parameter "logic" tidak ditemukan' });
      }

      const response = await axios.post(
        "https://ragbot-starter.vercel.app/api/chat",
        {
          messages: [
            {
              role: "assistant",
              content: logic,
            },
            {
              role: "user",
              content: q,  
            },
          ],
          useRag: true,
          llm: "gpt-4o", 
          similarityMetric: "cosine", 
        }
      );

      const data = response.data;
      res.status(200).json({
        status: 200,
        creator: "fdteam",
        data,
      });

    } catch (error) {
      console.error("Error:", error.message || error);
      res.status(500).json({
        error: "Waduh, terjadi kesalahan saat mengakses ragbot. Coba lagi nanti!"
      });
    }
  });
};