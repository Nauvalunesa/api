/*
wa.me/6289687537657
github: https://github.com/Phmiuuu
Instagram: https://instagram.com/basrenggood
ini wm gw cok jan di hapus
*/

const axios = require("axios");
const FormData = require('form-data');
const fs = require('fs');
const {
    Buffer
} = require("buffer")
const crypto = require("crypto")
module.exports = function(app) {

    app.post('/image-remini', async (req, res) => {
        const {
            url,
            method
        } = req.query;

        if (!url) {
            return res.status(400).json({
                error: 'Missing "url" in request query'
            });
        }

        try {
            // Ambil gambar dari URL yang diberikan
            const response = await axios.get(url, {
                responseType: 'arraybuffer'
            });
            const bufferData = Buffer.from(response.data);

            const processedBuffer = await remini(bufferData, "enhance");

            if (processedBuffer.length === 0) {
                throw new Error('Processed buffer is empty');
            }

            // Convert the processed buffer to a Base64 string
         /*   const base64Image = processedBuffer.toString('base64');
            const imageDataUrl = `data:image/png;base64,${base64Image}`;
            let hasil = Buffer.from(imageDataUrl, 'base64');*/
            const randomBytes = crypto.randomBytes(5).toString("hex");
            const form = new FormData();
            form.append('file', processedBuffer, `${randomBytes}.jpg`);

            const responseUploader = await axios.post('https://nvlgroup.my.id/api/upload', form, {
                headers: {
                    ...form.getHeaders()
                }
            });
            let {
                status,
                data
            } = responseUploader
            console.log('Upscaling Sukses');
            res.writeHead(200, {
              'Content-Type': 'image/jpeg',
              'Content-Length': processedBuffer
            });
            res.end(processedBuffer);
        } catch (error) {
            console.error('Error upscaling image:', error.message);
            res.status(500).json({
                status: false,
                message: 'Failed to upscale image'
            });
        }
    });

}


// Upscaling route
async function remini(urlPath, method) {
    return new Promise(async (resolve, reject) => {
        let Methods = ["enhance", "recolor", "dehaze"];
        Methods.includes(method) ? (method = method) : (method = Methods[0]);
        let buffer,
            Form = new FormData(),
            scheme = "https" + "://" + "inferenceengine" + ".vyro" + ".ai/" + method;
        Form.append("model_version", 1, {
            "Content-Transfer-Encoding": "binary",
            contentType: "multipart/form-data; charset=uttf-8",
        });
        Form.append("image", Buffer.from(urlPath), {
            filename: "enhance_image_body.jpg",
            contentType: "image/jpeg",
        });
        Form.submit({
                url: scheme,
                host: "inferenceengine" + ".vyro" + ".ai",
                path: "/" + method,
                protocol: "https:",
                headers: {
                    "User-Agent": "okhttp/4.9.3",
                    Connection: "Keep-Alive",
                    "Accept-Encoding": "gzip",
                },
            },
            function(err, res) {
                if (err) reject();
                let data = [];
                res
                    .on("data", function(chunk, resp) {
                        data.push(chunk);
                    })
                    .on("end", () => {
                        resolve(Buffer.concat(data));
                    });
                res.on("error", (e) => {
                    reject();
                });
            },
        );
    });
}