const axios = require("axios");

module.exports = function(app) {
  app.get('/ai/openai', async (req, res) => {
    try {
      const { q, prompt } = req.query;
      if (!q) {
        return res.status(400).json({ error: 'Parameter "q" hilang!' });
      }
      if (!prompt) {
        return res.status(400).json({ error: 'Parameter "prompt" hilang!' });
      }

      try {
        const response = await axios.get(`https://ytapi.hoshiliz.my.id/ai-openai?key=veliona&q=${encodeURIComponent(q)}&prompt=${encodeURIComponent(prompt)}`);
        const oke = response.data;

        res.status(200).json({
          status: 200,
          creator: "fdteam",
          message: oke
        });

      } catch (error) {
        console.error("Error :", error);
        res.status(500).json({ error: "Waduh, ada error nih! Kiana juga bingung..." });
      }

    } catch (error) {      
      res.status(500).json({ error: "Kesalahan tak terduga terjadi!" });
    }
  });
};
