const axios = require("axios");
const FormData = require('form-data');
const fs = require('fs');
const { Buffer } = require("buffer")
const crypto = require("crypto")
const express = require('express');

const app = express();
module.exports = function(app) {
  app.use(express.json());
  app.post('/ai/txt2img', async (req, res) => {
    try {
      const {
        sampler,
        width,
        height,
        upscale,
        cfg_scale,
        steps,
        style_preset,
        negative_prompt,
        prompt,
        model,
        loras,
        embeddings
      } = req.body

      if (!prompt) {
        return res.status(400).json({
          message: 'Missing required field: prompt',
          requiredFields: [
            'prompt',
            'sampler',
            'width',
            'height',
            'upscale',
            'cfg_scale',
            'steps',
            'style_preset',
            'negative_prompt',
            'model',
            'loras',
            'embeddings'
          ]
        });
      }
      
      const txt2img = async (apiKey = "8be49e35-8bf1-4553-b4cb-148bf2165260") => {
        const base = "https://api.prodia.com/v1";
        const headers = {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-Prodia-Key": apiKey,
        };

        const sendRequest = async ({
          link,
          method,
          params
        }) => {
          const url = `${base}${link}`;
          const options = {
            method: method,
            headers: headers,
          };

          if (method === "GET" && params) {
            options.params = params;
          } else if (params) {
            options.data = params;
          }

          const response = await axios(url, options);
          const data = response.data;

          if (!response.status === 200) {
            const errorMessages = {
              400: "The provided parameters are invalid.",
              401: "The provided API key is invalid.",
              402: "The API key is not enabled.",
            };
            throw new Error(errorMessages[response.status] || "Failed to receive a valid response.");
          }

          return data;
        };

        return {
          generateImage: async (params) => {
            return await sendRequest({
              link: "/sd/generate",
              method: "POST",
              params,
            });
          },
          upscale: async (params) => {
            return await sendRequest({
              link: "/upscale",
              method: "POST",
              params,
            });
          },
          wait: async (job) => {
            let res = job;
            while (res.status !== "succeeded") {
              await new Promise((resolve) => setTimeout(resolve, 250));
              if (res.status === "failed") throw new Error("Failed to generate image.");
              res = await sendRequest({
                link: `/job/${job.job}`,
                method: "GET",
              });
            }
            return res;
          },
        };
      };

      const apiKey = "25b15755-c155-4314-a535-8bb719e76358";
      const txt2imgInstance = await txt2img(apiKey);

      let proses = await txt2imgInstance.generateImage({
        sampler,
        width,
        height,
        upscale,
        cfg_scale,
        steps,
        style_preset,
        negative_prompt,
        prompt,
        model,
        loras,
        embeddings,
      });

      let hasil = await txt2imgInstance.wait(proses);
      let url = hasil.imageUrl
      let upload = await uploadKiana(url)

      res.status(200).json({
        status: true,
        creator: 'FD-Team',
        imageUrl: upload
      });
    } catch (error) {
      res.status(500).json({
        error: error.message
      });
    }
  });
};

async function uploadKiana(fileUrl) {
    try {
      const response = await axios.get(fileUrl, {
        responseType: 'arraybuffer'
      });
      const fileBuffer = Buffer.from(response.data);
      const formData = new FormData();
      formData.append('file', fileBuffer, {
        filename: 'file.png',
        contentType: 'image/png'
      });
      const uploadResponse = await axios.post('https://nvlgroup.my.id/api/upload', formData, {
        headers: {
          ...formData.getHeaders(),
        },
      });
      return uploadResponse.data.data.url
    } catch (error) {
      console.error('Error uploading file:', error.message);
      return false;
    }
}