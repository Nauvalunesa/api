/*
wa.me/6289687537657
github: https://github.com/Phmiuuu
Instagram: https://instagram.com/basrenggood
ini wm gw cok jan di hapus
*/

const express = require('express');
const axios = require('axios');
const app = express();

module.exports = function(app) {
  app.use(express.json());
  app.post('/ai/upscale', async (req, res) => {
    try {
      const {
        imageUrl,
        model,
        resize
      } = req.body
    
      if (!imageUrl) {
        return res.status(400).json({ error: 'Parameter "imageUrl" tidak ditemukan' });
      }
      
      const txt2img = async (apiKey = "25b15755-c155-4314-a535-8bb719e76358") => {
        const base = "https://api.prodia.com/v1";
        const headers = {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-Prodia-Key": apiKey,
        };

        const sendRequest = async ({ link, method, params }) => {
          const url = `${base}${link}`;
          const options = {
            method: method,
            headers: headers,
          };

          if (method === "GET" && params) {
            options.params = params;
          } else if (params) {
            options.data = params;
          }

          const response = await axios(url, options);
          const data = response.data;

          if (!response.status === 200) {
            const errorMessages = {
              400: "The provided parameters are invalid.",
              401: "The provided API key is invalid.",
              402: "The API key is not enabled.",
            };
            throw new Error(errorMessages[response.status] || "Failed to receive a valid response.");
          }

          return data;
        };

        return {
          upscale: async (params) => {
            return await sendRequest({
              link: "/upscale",
              method: "POST",
              params,
            });
          },
          wait: async (job) => {
            let res = job;
            while (res.status !== "succeeded") {
              await new Promise((resolve) => setTimeout(resolve, 250));
              if (res.status === "failed") throw new Error("Failed to generate image.");
              res = await sendRequest({
                link: `/job/${job.job}`,
                method: "GET",
              });
            }
            return res;
          },
        };
      };

      const apiKey = "25b15755-c155-4314-a535-8bb719e76358";
      const txt2imgInstance = await txt2img(apiKey);
      const paramHd = {
      imageUrl: imageUrl,
      model: model || "R-ESRGAN 4x+ Anime6B",
      resize: resize || 2
      }
      let hdin = await txt2imgInstance.upscale(paramHd);
      let hd = await txt2imgInstance.wait(hdin);

      res.status(200).json({
        status: true,
        creator: 'FD-Team',
        imageUrl: hd.imageUrl
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
};